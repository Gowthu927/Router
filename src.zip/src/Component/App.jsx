import React from 'react';
import {Route,Switch,BrowserRouter as Router,Link} from 'react-router-dom';
import Contact from './Contact';
import Home from './Home';

class App extends React.Component{
    render(){
        return(
            <div>
                
                <Router>
                <ul>
                    <li>
                        <Link to="/table">Table</Link>
                    </li>
                    <li>
                        <Link to="/contact">Contact</Link>
                    </li>
                </ul>
                    <Switch>
                        <Route path='/table' component={Home} />
                        <Route path='/contact' component={Contact} />
                    </Switch>
                </Router>
            </div>
        );
    }
}

export default App;