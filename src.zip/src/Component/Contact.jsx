import React from 'react';
import axios from 'axios';



class Contact extends React.Component{
    state={
        fetchedData:[]
    }

   componentDidMount=()=>{
       this.getData()
   }
   getData= async()=>{
        let data=await axios.get('https://jsonplaceholder.typicode.com/users');
        this.setState({fetchedData:data.data})
        
   }
    render(){
        console.log(JSON.stringify(this.state.fetchedData))
        return(
            <div>
                <h2>Contact Page</h2>
                {this.state.fetchedData.map(data=>{
                    return(
                        <p>{data.name}</p>
                    );
                })}

            </div>
        );
    }
}

export default Contact;